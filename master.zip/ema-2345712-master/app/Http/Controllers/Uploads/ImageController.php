<?php

namespace App\Http\Controllers\Uploads;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Account\StoreAvatarFormRequest;

class ImageController extends Controller
{
    public function store(StoreAvatarFormRequest $request)
    {
    	
    }
}
