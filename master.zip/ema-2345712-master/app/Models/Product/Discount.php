<?php

namespace App\Models\Product;

use Illuminate\Database\Eloquent\Model;

class Discount extends Model
{
    //
}
