<?php

namespace App\Models\Traits;

use Illuminate\Database\Eloquent\Builder;

trait IsOrderable
{
    public function scopeOrdered(Builder $builder, $direction = 'desc')
    {
        $builder->orderBy('order', $direction);
    }
}
