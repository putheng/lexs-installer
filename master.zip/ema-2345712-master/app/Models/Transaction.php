<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    /**
     * [$fillable description]
     * @var [type]
     */
    protected $fillable = [
        'total', 'type', 'symbol'
    ];
}
